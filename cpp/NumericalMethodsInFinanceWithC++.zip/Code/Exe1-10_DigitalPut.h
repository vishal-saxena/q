#ifndef Exe1_10_DigitalPut_h
#define Exe1_10_DigitalPut_h

//computing digital put payoff
double DigitalPutPayoff(double z, double K);

#endif
